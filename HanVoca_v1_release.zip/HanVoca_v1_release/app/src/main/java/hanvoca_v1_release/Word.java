package hanvoca_v1_release;

public class Word {
    String word;
    String mean;
    int index;
    String voca;


    void init(){

        word = "temp";
        mean = "임시단어임";
        index = 0;
        voca = "TempVoca";

    }
}
