package hanvoca_v1_release;

public class Voca {
    String name;
    int numOfWords;



    void set(String vocaname){
        name = vocaname;
        numOfWords = 0;
    }

}
