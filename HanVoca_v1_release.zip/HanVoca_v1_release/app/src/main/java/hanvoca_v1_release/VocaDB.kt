package hanvoca_v1_release

import io.realm.RealmObject

open class VocaDB (
    var name:String=" ",
    var numOfWords:Int=0
):RealmObject(){

}