package hanvoca_v1_release

import android.os.Bundle
import android.support.v7.app.AppCompatActivity

import com.example.onejo.hanvoca_v1_release.R

class   getWordActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_get_word)








    }
}
